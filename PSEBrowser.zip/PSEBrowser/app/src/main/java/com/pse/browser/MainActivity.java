package com.pse.browser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private EditText addressBar;
    private ProgressBar progressBar;
    private ImageButton btnBack, btnReload, btnDesktop;
    private boolean isDesktopMode = false;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingPickImageId = null;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final long[] tapTimes = new long[3];
    private int tapIndex = 0;
    private static final int TAP_AREA_RIGHT = 90;
    private static final int TAP_AREA_BOTTOM = 190;
    private static final long TAP_WINDOW_MS = 900;

    private final ActivityResultLauncher<Intent> fileChooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) return;
                Uri[] results = null;
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Uri data = result.getData().getData();
                    if (data != null) results = new Uri[]{data};
                }
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            });

    private final ActivityResultLauncher<Intent> imagePickerLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (pendingPickImageId == null) return;
                String id = pendingPickImageId;
                pendingPickImageId = null;
                if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null) {
                    sendCb(id, false, null);
                    return;
                }
                Uri uri = result.getData().getData();
                if (uri == null) {
                    sendCb(id, false, null);
                    return;
                }
                executor.execute(() -> {
                    try {
                        InputStream is = getContentResolver().openInputStream(uri);
                        Bitmap bmp = BitmapFactory.decodeStream(is);
                        if (is != null) is.close();
                        if (bmp == null) {
                            sendCb(id, false, null);
                            return;
                        }
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        int maxDim = 1600;
                        float scale = 1f;
                        if (bmp.getWidth() > maxDim || bmp.getHeight() > maxDim) {
                            scale = Math.min((float) maxDim / bmp.getWidth(), (float) maxDim / bmp.getHeight());
                        }
                        Bitmap scaled = bmp;
                        if (scale < 1f) {
                            scaled = Bitmap.createScaledBitmap(bmp,
                                    (int) (bmp.getWidth() * scale),
                                    (int) (bmp.getHeight() * scale), true);
                            bmp.recycle();
                        }
                        scaled.compress(Bitmap.CompressFormat.JPEG, 85, baos);
                        if (scaled != bmp) scaled.recycle();
                        byte[] bytes = baos.toByteArray();
                        if (bytes.length > 1_500_000) {
                            baos.reset();
                            Bitmap smaller = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            smaller.compress(Bitmap.CompressFormat.JPEG, 70, baos);
                            smaller.recycle();
                            bytes = baos.toByteArray();
                        }
                        String dataUrl = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
                        sendCb(id, true, dataUrl);
                    } catch (Exception e) {
                        sendCb(id, false, null);
                    }
                });
            });

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        root.setBackgroundColor(Color.WHITE);

        // Toolbar
        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setBackgroundColor(Color.parseColor("#1a1a1a"));
        toolbar.setPadding(8, 12, 8, 12);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(toolbar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        btnBack = new ImageButton(this);
        btnBack.setImageResource(android.R.drawable.ic_media_previous);
        btnBack.setBackgroundColor(Color.TRANSPARENT);
        btnBack.setColorFilter(Color.WHITE);
        btnBack.setPadding(16, 8, 16, 8);
        btnBack.setOnClickListener(v -> {
            if (webView.canGoBack()) webView.goBack();
            else finish();
        });
        toolbar.addView(btnBack, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        addressBar = new EditText(this);
        addressBar.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        addressBar.setHint("URL ya search...");
        addressBar.setHintTextColor(Color.parseColor("#aaaaaa"));
        addressBar.setTextColor(Color.WHITE);
        addressBar.setBackgroundColor(Color.parseColor("#333333"));
        addressBar.setPadding(16, 12, 16, 12);
        addressBar.setSingleLine(true);
        addressBar.setImeOptions(EditorInfo.IME_ACTION_GO);
        addressBar.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        addressBar.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO ||
                    (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_DOWN)) {
                loadFromAddressBar();
                return true;
            }
            return false;
        });
        toolbar.addView(addressBar);

        btnReload = new ImageButton(this);
        btnReload.setImageResource(android.R.drawable.ic_popup_sync);
        btnReload.setBackgroundColor(Color.TRANSPARENT);
        btnReload.setColorFilter(Color.WHITE);
        btnReload.setPadding(16, 8, 16, 8);
        btnReload.setOnClickListener(v -> webView.reload());
        toolbar.addView(btnReload, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        btnDesktop = new ImageButton(this);
        btnDesktop.setImageResource(android.R.drawable.ic_menu_view);
        btnDesktop.setBackgroundColor(Color.TRANSPARENT);
        btnDesktop.setColorFilter(Color.WHITE);
        btnDesktop.setPadding(16, 8, 16, 8);
        btnDesktop.setOnClickListener(v -> toggleDesktopMode());
        toolbar.addView(btnDesktop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 6));
        progressBar.setMax(100);
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        root.addView(progressBar);

        FrameLayout webContainer = new FrameLayout(this);
        webContainer.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(webContainer);

        webView = new WebView(this);
        webView.setLayoutParams(new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webContainer.addView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setDatabaseEnabled(true);
        ws.setSupportZoom(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setUseWideViewPort(true);
        ws.setLoadWithOverviewMode(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new PSE_Native(), "PSE_Native");

        final String editorJs = loadAsset("editor.js");
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(webView, editorJs, java.util.Collections.singleton("*"));
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                if (scheme == null) return false;
                if ("http".equals(scheme) || "https".equals(scheme) || "about".equals(scheme)) {
                    return false;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                    startActivity(intent);
                } catch (Exception ignored) {}
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                addressBar.setText(url);
                progressBar.setVisibility(View.VISIBLE);
                view.evaluateJavascript(editorJs, null);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progressBar.setVisibility(View.GONE);
                view.evaluateJavascript(editorJs, null);
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (d, w) -> result.confirm())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, android.webkit.JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("Haan", (d, w) -> result.confirm())
                        .setNegativeButton("Nahi", (d, w) -> result.cancel())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue,
                                     android.webkit.JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                input.setText(defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton("OK", (d, w) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("Cancel", (d, w) -> result.cancel())
                        .setCancelable(false)
                        .show();
                return true;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                MainActivity.this.filePathCallback = filePathCallback;
                try {
                    fileChooserLauncher.launch(fileChooserParams.createIntent());
                } catch (Exception e) {
                    MainActivity.this.filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Triple-tap bottom-right (do NOT consume events)
        webView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                int w = v.getWidth();
                int h = v.getHeight();
                float x = event.getX();
                float y = event.getY();
                if (x > w - TAP_AREA_RIGHT && y > h - TAP_AREA_BOTTOM) {
                    long now = System.currentTimeMillis();
                    tapTimes[tapIndex % 3] = now;
                    tapIndex++;
                    if (tapIndex >= 3) {
                        long t0 = tapTimes[(tapIndex - 3) % 3];
                        long t2 = tapTimes[(tapIndex - 1) % 3];
                        if (t2 - t0 <= TAP_WINDOW_MS) {
                            webView.evaluateJavascript(
                                    "(function(){if(window.__pseOpenEdit)window.__pseOpenEdit();})();", null);
                            tapIndex = 0;
                        }
                    }
                }
            }
            return false;
        });

        setContentView(root);
        handleIntent(getIntent());
        if (webView.getUrl() == null) {
            webView.loadUrl("https://www.google.com");
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null) return;
        Uri data = intent.getData();
        if (data != null) {
            String url = data.toString();
            if (url.startsWith("http://") || url.startsWith("https://")) {
                webView.loadUrl(url);
            }
        }
    }

    private void loadFromAddressBar() {
        String input = addressBar.getText().toString().trim();
        if (input.isEmpty()) return;
        String url;
        if (input.contains(" ") || !input.contains(".")) {
            url = "https://www.google.com/search?q=" + Uri.encode(input);
        } else if (!input.startsWith("http://") && !input.startsWith("https://")) {
            url = "https://" + input;
        } else {
            url = input;
        }
        webView.loadUrl(url);
    }

    private void toggleDesktopMode() {
        isDesktopMode = !isDesktopMode;
        WebSettings ws = webView.getSettings();
        if (isDesktopMode) {
            ws.setUserAgentString("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
            btnDesktop.setColorFilter(Color.parseColor("#4a90e2"));
        } else {
            ws.setUserAgentString(null);
            btnDesktop.setColorFilter(Color.WHITE);
        }
        webView.reload();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    private String loadAsset(String name) {
        try {
            InputStream is = getAssets().open(name);
            BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            br.close();
            return sb.toString();
        } catch (Exception e) {
            return "console.error('editor.js load failed');";
        }
    }

    private void sendCb(String id, boolean ok, String data) {
        mainHandler.post(() -> {
            try {
                String escaped = data == null ? "null" : JSONObject.quote(data);
                String js = "window.__pseCb && window.__pseCb(" + JSONObject.quote(id) + "," + ok + "," + escaped + ");";
                webView.evaluateJavascript(js, null);
            } catch (Exception ignored) {}
        });
    }

    private File getPseDir() {
        File dir = new File(getFilesDir(), "pse");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private String sha1(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] dig = md.digest(input.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : dig) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            return Integer.toHexString(input.hashCode());
        }
    }

    public class PSE_Native {
        @JavascriptInterface
        public String getValue(String key) {
            try {
                File f = new File(getPseDir(), sha1(key));
                if (!f.exists()) return null;
                FileInputStream fis = new FileInputStream(f);
                byte[] buf = new byte[(int) f.length()];
                fis.read(buf);
                fis.close();
                return new String(buf, StandardCharsets.UTF_8);
            } catch (Exception e) {
                return null;
            }
        }

        @JavascriptInterface
        public boolean setValue(String key, String value) {
            try {
                File f = new File(getPseDir(), sha1(key));
                FileOutputStream fos = new FileOutputStream(f);
                fos.write(value.getBytes(StandardCharsets.UTF_8));
                fos.close();
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean deleteValue(String key) {
            try {
                File f = new File(getPseDir(), sha1(key));
                return f.exists() && f.delete();
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void fetch(String id, String url, String type) {
            executor.execute(() -> {
                HttpURLConnection conn = null;
                try {
                    URL u = new URL(url);
                    conn = (HttpURLConnection) u.openConnection();
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(20000);
                    conn.setRequestProperty("User-Agent", webView.getSettings().getUserAgentString());
                    String cookies = CookieManager.getInstance().getCookie(url);
                    if (cookies != null) conn.setRequestProperty("Cookie", cookies);
                    String current = webView.getUrl();
                    if (current != null) conn.setRequestProperty("Referer", current);
                    conn.connect();
                    int code = conn.getResponseCode();
                    if (code >= 400) {
                        sendCb(id, false, null);
                        return;
                    }
                    InputStream is = conn.getInputStream();
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int total = 0;
                    int n;
                    while ((n = is.read(buf)) != -1) {
                        total += n;
                        if (total > 15 * 1024 * 1024) {
                            sendCb(id, false, null);
                            return;
                        }
                        baos.write(buf, 0, n);
                    }
                    is.close();
                    byte[] data = baos.toByteArray();
                    if ("dataurl".equals(type)) {
                        String mime = conn.getContentType();
                        if (mime == null) mime = "application/octet-stream";
                        if (mime.contains(";")) mime = mime.split(";")[0].trim();
                        String b64 = Base64.encodeToString(data, Base64.NO_WRAP);
                        sendCb(id, true, "data:" + mime + ";base64," + b64);
                    } else {
                        sendCb(id, true, new String(data, StandardCharsets.UTF_8));
                    }
                } catch (Exception e) {
                    sendCb(id, false, null);
                } finally {
                    if (conn != null) conn.disconnect();
                }
            });
        }

        @JavascriptInterface
        public void pickImage(String id) {
            pendingPickImageId = id;
            Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
            intent.setType("image/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            try {
                imagePickerLauncher.launch(Intent.createChooser(intent, "Image chuno"));
            } catch (Exception e) {
                pendingPickImageId = null;
                sendCb(id, false, null);
            }
        }

        @JavascriptInterface
        public void saveFile(String name, String content) {
            executor.execute(() -> {
                try {
                    String fileName = name.endsWith(".html") ? name : name + ".html";
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, fileName);
                    values.put(MediaStore.Downloads.MIME_TYPE, "text/html");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) {
                        mainHandler.post(() -> Toast.makeText(MainActivity.this, "Save fail", Toast.LENGTH_SHORT).show());
                        return;
                    }
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    if (os != null) {
                        os.write(content.getBytes(StandardCharsets.UTF_8));
                        os.close();
                    }
                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    getContentResolver().update(uri, values, null, null);
                    mainHandler.post(() -> Toast.makeText(MainActivity.this, "Saved: " + fileName, Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    mainHandler.post(() -> Toast.makeText(MainActivity.this, "Save error", Toast.LENGTH_SHORT).show());
                }
            });
        }
    }
}
