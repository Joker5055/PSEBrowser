(function () {
  if (window.__pseLoaded) return;
  window.__pseLoaded = true;
  if (window !== window.top) return;

  // Trusted Types fallback
  let policy = null;
  try {
    if (window.trustedTypes && trustedTypes.createPolicy) {
      policy = trustedTypes.createPolicy('pse', {
        createHTML: (s) => s,
        createScript: (s) => s,
        createScriptURL: (s) => s
      });
    }
  } catch (e) {}
  function safeHTML(html) {
    return policy ? policy.createHTML(html) : html;
  }

  // Storage via native
  function getStored(key) {
    try { return PSE_Native.getValue(key); } catch (e) { return null; }
  }
  function setStored(key, val) {
    try { return PSE_Native.setValue(key, val); } catch (e) { return false; }
  }
  function delStored(key) {
    try { return PSE_Native.deleteValue(key); } catch (e) { return false; }
  }

  function pageKey() {
    try { return location.origin + location.pathname; } catch (e) { return location.href; }
  }

  // Early hide for saved edits
  let hasSaved = false;
  let savedBody = null;
  let savedTitle = null;
  try {
    const raw = getStored('edit:' + pageKey());
    if (raw) {
      const obj = JSON.parse(raw);
      if (obj && obj.body) {
        hasSaved = true;
        savedBody = obj.body;
        savedTitle = obj.title || '';
      }
    }
  } catch (e) {}

  if (hasSaved) {
    try {
      document.documentElement.style.setProperty('visibility', 'hidden', 'important');
    } catch (e) {}
    setTimeout(function () {
      try { document.documentElement.style.removeProperty('visibility'); } catch (e) {}
    }, 6000);
  }

  function applySaved() {
    if (!hasSaved || !savedBody) return;
    try {
      if (document.body) {
        document.body.innerHTML = safeHTML(savedBody);
        if (savedTitle) document.title = savedTitle;
        document.documentElement.style.removeProperty('visibility');
      }
    } catch (e) {}
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', applySaved, { once: true });
  } else {
    applySaved();
  }

  // Re-apply after 1.2s if site changed body (edit mode off)
  setTimeout(function () {
    if (hasSaved && !window.__pseEditMode && document.body) {
      try {
        document.body.innerHTML = safeHTML(savedBody);
        if (savedTitle) document.title = savedTitle;
      } catch (e) {}
    }
  }, 1200);

  // Native callbacks
  const cbs = {};
  window.__pseCb = function (id, ok, data) {
    const fn = cbs[id];
    if (fn) {
      delete cbs[id];
      fn(ok, data);
    }
  };
  function callNative(method, arg1, arg2) {
    return new Promise(function (resolve) {
      const id = 'cb_' + Date.now() + '_' + Math.random().toString(36).slice(2);
      cbs[id] = function (ok, data) { resolve({ ok: ok, data: data }); };
      try {
        if (method === 'fetch') PSE_Native.fetch(id, arg1, arg2);
        else if (method === 'pickImage') PSE_Native.pickImage(id);
        else resolve({ ok: false });
      } catch (e) { resolve({ ok: false }); }
    });
  }

  // Editor UI
  let shadowHost = null;
  let shadow = null;
  let toolbar = null;
  window.__pseEditMode = false;
  let designModeWas = 'off';
  let undoStack = [];
  let currentTool = null;
  let colorMap = [];

  function createEditorUI() {
    if (shadowHost) return;
    shadowHost = document.createElement('div');
    shadowHost.id = '__pse_host';
    shadowHost.style.cssText = 'all:initial;position:fixed;left:0;right:0;bottom:0;z-index:2147483647;pointer-events:none;';
    document.documentElement.appendChild(shadowHost);
    shadow = shadowHost.attachShadow({ mode: 'open' });

    const sheet = new CSSStyleSheet();
    sheet.replaceSync([
      ':host { all: initial; }',
      '* { box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif; }',
      '.bar { pointer-events: auto; background: #1a1a1a; color: #fff; padding: 8px 6px;',
      '  display: flex; flex-wrap: wrap; gap: 6px; align-items: center;',
      '  max-height: 42vh; overflow-y: auto; border-top: 2px solid #4a90e2; font-size: 13px; }',
      '.btn { background: #333; color: #fff; border: none; border-radius: 6px; padding: 7px 10px; cursor: pointer; white-space: nowrap; }',
      '.btn:active, .btn.active { background: #4a90e2; }',
      '.btn.danger { background: #c0392b; }',
      '.btn.close { background: #555; margin-left: auto; }',
      '.color-item { display: flex; align-items: center; gap: 4px; background: #2a2a2a; padding: 4px 6px; border-radius: 4px; }',
      '.swatch { width: 18px; height: 18px; border-radius: 3px; border: 1px solid #666; cursor: pointer; }',
      '.info { font-size: 11px; color: #aaa; }',
      'input[type=color] { width: 28px; height: 24px; border: none; padding: 0; background: none; cursor: pointer; }'
    ].join('\n'));
    shadow.adoptedStyleSheets = [sheet];

    toolbar = document.createElement('div');
    toolbar.className = 'bar';
    shadow.appendChild(toolbar);
    renderToolbar();
  }

  function renderToolbar() {
    if (!toolbar) return;
    toolbar.innerHTML = '';
    const tools = [
      { id: 'text', label: 'Text' },
      { id: 'image', label: 'Image/Logo' },
      { id: 'colors', label: 'Colors' },
      { id: 'link', label: 'Link' },
      { id: 'add', label: 'Add' },
      { id: 'delete', label: 'Delete' },
      { id: 'undo', label: 'Undo' },
      { id: 'rename', label: 'Naam badlo' },
      { id: 'title', label: 'Title' },
      { id: 'keep', label: 'Keep' },
      { id: 'reset', label: 'Reset' },
      { id: 'save', label: 'Save' }
    ];
    tools.forEach(function (t) {
      const b = document.createElement('button');
      b.className = 'btn' + (currentTool === t.id ? ' active' : '');
      b.textContent = t.label;
      b.onclick = function () { onTool(t.id); };
      toolbar.appendChild(b);
    });
    const close = document.createElement('button');
    close.className = 'btn close';
    close.textContent = '✖';
    close.onclick = function () { closeEdit(); };
    toolbar.appendChild(close);

    if (currentTool === 'colors' && colorMap.length) {
      colorMap.forEach(function (c, idx) {
        const item = document.createElement('div');
        item.className = 'color-item';
        const sw = document.createElement('div');
        sw.className = 'swatch';
        sw.style.background = c.color;
        const info = document.createElement('span');
        info.className = 'info';
        info.textContent = c.type + ' ×' + c.count;
        const picker = document.createElement('input');
        picker.type = 'color';
        picker.value = rgbToHex(c.color) || '#000000';
        picker.oninput = function () { applyColorChange(idx, picker.value); };
        item.appendChild(sw);
        item.appendChild(info);
        item.appendChild(picker);
        toolbar.appendChild(item);
      });
    }
  }

  function rgbToHex(rgb) {
    if (!rgb) return null;
    if (rgb.startsWith('#')) return rgb.slice(0, 7);
    const m = rgb.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/);
    if (!m) return null;
    return '#' + [m[1], m[2], m[3]].map(function (x) {
      return (+x).toString(16).padStart(2, '0');
    }).join('');
  }

  function onTool(id) {
    if (id === 'undo') { doUndo(); return; }
    if (id === 'keep') { doKeep(); return; }
    if (id === 'reset') { doReset(); return; }
    if (id === 'save') { doSave(); return; }
    if (id === 'title') { doTitle(); return; }
    if (id === 'rename') { doRename(); return; }
    if (id === 'colors') {
      currentTool = currentTool === 'colors' ? null : 'colors';
      if (currentTool === 'colors') scanColors();
      renderToolbar();
      return;
    }
    if (id === 'text') {
      currentTool = null;
      renderToolbar();
      return;
    }
    currentTool = currentTool === id ? null : id;
    renderToolbar();
  }

  function pushUndo(fn) {
    undoStack.push(fn);
    if (undoStack.length > 50) undoStack.shift();
  }
  function doUndo() {
    const fn = undoStack.pop();
    if (fn) try { fn(); } catch (e) {}
  }

  function scanColors() {
    colorMap = [];
    const seen = new Map();
    const props = [
      { prop: 'color', type: 'text' },
      { prop: 'backgroundColor', type: 'bg' },
      { prop: 'borderColor', type: 'border' },
      { prop: 'fill', type: 'svg' }
    ];
    document.querySelectorAll('*').forEach(function (el) {
      if (el.closest('#__pse_host')) return;
      const st = getComputedStyle(el);
      props.forEach(function (p) {
        let val = st[p.prop];
        if (!val || val === 'transparent' || val === 'rgba(0, 0, 0, 0)') return;
        const key = val + '|' + p.type;
        if (!seen.has(key)) {
          seen.set(key, { color: val, type: p.type, count: 0, elements: [] });
          colorMap.push(seen.get(key));
        }
        const entry = seen.get(key);
        entry.count++;
        if (entry.elements.length < 30) entry.elements.push(el);
      });
    });
    colorMap.sort(function (a, b) { return b.count - a.count; });
    colorMap = colorMap.slice(0, 14);
  }

  function applyColorChange(idx, newHex) {
    const entry = colorMap[idx];
    if (!entry) return;
    const old = entry.color;
    entry.elements.forEach(function (el) {
      try {
        if (entry.type === 'text') el.style.setProperty('color', newHex, 'important');
        else if (entry.type === 'bg') el.style.setProperty('background-color', newHex, 'important');
        else if (entry.type === 'border') el.style.setProperty('border-color', newHex, 'important');
        else if (entry.type === 'svg') el.style.setProperty('fill', newHex, 'important');
      } catch (e) {}
    });
    document.querySelectorAll('*').forEach(function (el) {
      if (el.closest('#__pse_host')) return;
      const st = getComputedStyle(el);
      if (entry.type === 'text' && st.color === old) el.style.setProperty('color', newHex, 'important');
      if (entry.type === 'bg' && st.backgroundColor === old) el.style.setProperty('background-color', newHex, 'important');
      if (entry.type === 'border' && st.borderColor === old) el.style.setProperty('border-color', newHex, 'important');
      if (entry.type === 'svg' && st.fill === old) el.style.setProperty('fill', newHex, 'important');
    });
    entry.color = newHex;
    renderToolbar();
  }

  document.addEventListener('click', function (e) {
    if (!window.__pseEditMode) return;
    if (e.target.closest('#__pse_host')) return;
    if (currentTool === 'image') {
      e.preventDefault();
      e.stopPropagation();
      handleImagePick(e.target);
    } else if (currentTool === 'link') {
      e.preventDefault();
      e.stopPropagation();
      handleLink(e.target);
    } else if (currentTool === 'add') {
      e.preventDefault();
      e.stopPropagation();
      handleAdd(e.target);
    } else if (currentTool === 'delete') {
      e.preventDefault();
      e.stopPropagation();
      handleDelete(e.target);
    }
  }, true);

  async function handleImagePick(el) {
    let target = el;
    if (el.tagName !== 'IMG') {
      let cur = el;
      while (cur && cur !== document.body) {
        const bg = getComputedStyle(cur).backgroundImage;
        if (bg && bg !== 'none') { target = cur; break; }
        cur = cur.parentElement;
      }
    }
    const res = await callNative('pickImage');
    if (!res.ok || !res.data) return;
    const dataUrl = res.data;
    const prev = target.outerHTML;
    pushUndo(function () { try { target.outerHTML = prev; } catch (e) {} });
    if (target.tagName === 'IMG') {
      target.src = dataUrl;
      target.style.maxWidth = '100%';
      target.style.height = 'auto';
    } else {
      target.style.setProperty('background-image', 'url(' + dataUrl + ')', 'important');
      target.style.setProperty('background-size', 'contain', 'important');
    }
    currentTool = null;
    renderToolbar();
  }

  function handleLink(el) {
    let a = el.closest('a') || el;
    const oldHref = a.href || '';
    const oldText = a.innerText || a.textContent || '';
    const newUrl = prompt('Naya URL:', oldHref);
    if (newUrl === null) return;
    const newText = prompt('Naya text (khali chhoro to same):', oldText);
    const prev = a.outerHTML;
    pushUndo(function () { try { a.outerHTML = prev; } catch (e) {} });
    if (a.tagName !== 'A') {
      const na = document.createElement('a');
      na.href = newUrl;
      na.textContent = (newText !== null && newText !== '') ? newText : oldText;
      a.parentNode.replaceChild(na, a);
    } else {
      a.href = newUrl;
      if (newText !== null && newText !== '') a.textContent = newText;
    }
    currentTool = null;
    renderToolbar();
  }

  function handleAdd(el) {
    const type = prompt('Kya add karein? (text / heading / button / image)', 'text');
    if (!type) return;
    let node;
    if (type === 'heading') {
      node = document.createElement('h2');
      node.textContent = prompt('Heading text:', 'Nayi heading') || 'Nayi heading';
    } else if (type === 'button') {
      node = document.createElement('button');
      node.textContent = prompt('Button text:', 'Button') || 'Button';
      node.style.cssText = 'padding:8px 16px;background:#4a90e2;color:#fff;border:none;border-radius:4px;cursor:pointer;';
    } else if (type === 'image') {
      node = document.createElement('img');
      node.src = 'https://via.placeholder.com/150';
      node.style.maxWidth = '100%';
      node.alt = 'image';
    } else {
      node = document.createElement('p');
      node.textContent = prompt('Text:', 'Naya text') || 'Naya text';
    }
    const parent = el.parentNode || document.body;
    const next = el.nextSibling;
    parent.insertBefore(node, next);
    pushUndo(function () { try { node.remove(); } catch (e) {} });
    currentTool = null;
    renderToolbar();
  }

  function handleDelete(el) {
    if (el === document.body || el === document.documentElement) return;
    const parent = el.parentNode;
    const next = el.nextSibling;
    const clone = el.cloneNode(true);
    pushUndo(function () {
      try {
        if (next) parent.insertBefore(clone, next);
        else parent.appendChild(clone);
      } catch (e) {}
    });
    el.remove();
  }

  function doTitle() {
    const t = prompt('Naya page title:', document.title);
    if (t !== null) {
      const old = document.title;
      pushUndo(function () { document.title = old; });
      document.title = t;
    }
  }

  function doRename() {
    const find = prompt('Kya dhoondna hai?');
    if (!find) return;
    const replace = prompt('Kis se badalna hai?', find);
    if (replace === null) return;
    const doLinks = confirm('Links (href) mein bhi badalun?');
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    const texts = [];
    while (walker.nextNode()) texts.push(walker.currentNode);
    texts.forEach(function (n) {
      if (n.nodeValue && n.nodeValue.includes(find)) {
        const old = n.nodeValue;
        pushUndo(function () { n.nodeValue = old; });
        n.nodeValue = n.nodeValue.split(find).join(replace);
      }
    });
    document.querySelectorAll('[alt],[title],[placeholder]').forEach(function (el) {
      ['alt', 'title', 'placeholder'].forEach(function (attr) {
        if (el.hasAttribute(attr) && el.getAttribute(attr).includes(find)) {
          const old = el.getAttribute(attr);
          pushUndo(function () { el.setAttribute(attr, old); });
          el.setAttribute(attr, old.split(find).join(replace));
        }
      });
    });
    if (doLinks) {
      document.querySelectorAll('a[href]').forEach(function (a) {
        if (a.getAttribute('href').includes(find)) {
          const old = a.getAttribute('href');
          pushUndo(function () { a.setAttribute('href', old); });
          a.setAttribute('href', old.split(find).join(replace));
        }
      });
    }
  }

  function doKeep() {
    const body = document.body ? document.body.innerHTML : '';
    const title = document.title || '';
    setStored('edit:' + pageKey(), JSON.stringify({ body: body, title: title }));
    hasSaved = true;
    savedBody = body;
    savedTitle = title;
    alert('Edits is page ke liye save ho gaye.');
  }

  function doReset() {
    if (!confirm('Is page ke saved edits hataun aur reload karun?')) return;
    delStored('edit:' + pageKey());
    hasSaved = false;
    savedBody = null;
    location.reload();
  }

  async function doSave() {
    try {
      const clone = document.documentElement.cloneNode(true);
      const host = clone.querySelector('#__pse_host');
      if (host) host.remove();
      clone.querySelectorAll('script, noscript').forEach(function (s) { s.remove(); });
      clone.querySelectorAll('a[href]').forEach(function (a) {
        try { a.href = new URL(a.getAttribute('href'), location.href).href; } catch (e) {}
      });

      const styles = [];
      for (let i = 0; i < document.styleSheets.length; i++) {
        const sheet = document.styleSheets[i];
        try {
          if (sheet.href) {
            const res = await callNative('fetch', sheet.href, 'text');
            if (res.ok) styles.push(res.data);
          } else if (sheet.ownerNode && sheet.ownerNode.tagName === 'STYLE') {
            styles.push(sheet.ownerNode.textContent);
          }
        } catch (e) {}
      }

      const imgs = clone.querySelectorAll('img[src]');
      for (let i = 0; i < imgs.length; i++) {
        const img = imgs[i];
        const src = img.getAttribute('src');
        if (src.startsWith('data:')) continue;
        try {
          const abs = new URL(src, location.href).href;
          const res = await callNative('fetch', abs, 'dataurl');
          if (res.ok) img.setAttribute('src', res.data);
        } catch (e) {}
      }

      let cssText = styles.join('\n');
      const urlRe = /url\(['"]?([^'")]+)['"]?\)/g;
      let m;
      const replacements = [];
      while ((m = urlRe.exec(cssText)) !== null) {
        const u = m[1];
        if (u.startsWith('data:')) continue;
        try {
          const abs = new URL(u, location.href).href;
          const res = await callNative('fetch', abs, 'dataurl');
          if (res.ok) replacements.push({ from: m[0], to: 'url(' + res.data + ')' });
        } catch (e) {}
      }
      replacements.forEach(function (r) {
        cssText = cssText.split(r.from).join(r.to);
      });

      let head = clone.querySelector('head');
      if (!head) {
        head = document.createElement('head');
        clone.insertBefore(head, clone.firstChild);
      }
      head.querySelectorAll('link[rel=stylesheet]').forEach(function (l) { l.remove(); });
      const styleEl = document.createElement('style');
      styleEl.textContent = cssText;
      head.appendChild(styleEl);

      const html = '<!DOCTYPE html>\n' + clone.outerHTML;
      const name = (document.title || 'page').replace(/[^\w\u0600-\u06FF]+/g, '_').slice(0, 40) + '.html';
      PSE_Native.saveFile(name, html);
    } catch (e) {
      alert('Save error: ' + (e.message || e));
    }
  }

  function openEdit() {
    if (window.__pseEditMode) return;
    window.__pseEditMode = true;
    designModeWas = document.designMode;
    document.designMode = 'on';
    createEditorUI();
    renderToolbar();
  }

  function closeEdit() {
    if (!window.__pseEditMode) return;
    const keep = confirm('Edits keep karun?');
    if (keep) doKeep();
    window.__pseEditMode = false;
    document.designMode = designModeWas || 'off';
    currentTool = null;
    if (shadowHost) {
      shadowHost.remove();
      shadowHost = null;
      shadow = null;
      toolbar = null;
    }
  }

  window.__pseOpenEdit = openEdit;
})();
