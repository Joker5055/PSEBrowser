# PSE Browser – Website Editor App

Yeh Android app kisi bhi website ko WebView mein khol kar edit karne deti hai. Edit mode chhupa hua hai.

## Requirements
- minSdk 29, targetSdk 34, compileSdk 34
- AGP 8.5.2, Gradle 8.7
- Java 17
- androidx.appcompat 1.7.0, androidx.webkit 1.11.0

## APK kaise banayein

### Method 1: GitHub Actions (sab se aasan)
1. Is repo ko GitHub par push karein.
2. Actions tab mein "Build APK" workflow chalaein (ya push par auto chalega).
3. Artifacts se `app-debug.apk` download karein.

### Method 2: Android Studio
1. Android Studio mein project open karein (File → Open → PSEBrowser folder).
2. SDK 34 install ho (SDK Manager).
3. Build → Build Bundle(s) / APK(s) → Build APK(s).
4. `app/build/outputs/apk/debug/app-debug.apk` mil jayega.

### Method 3: Command line
```bash
# pehle gradle wrapper generate karo (agar nahi hai)
gradle wrapper --gradle-version 8.7

# build
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## App kaise use karein
1. App kholo → Google ya koi bhi site open karo.
2. **Edit mode kholne ke liye**: screen ke bilkul neeche-right corner (lagbhag 90px right + 190px bottom area) mein **900ms ke andar 3 baar tezi se tap** karo.
3. Neeche dark toolbar aa jayegi (Roman Urdu labels).
4. Tools:
   - **Text** – seedha type karo (designMode on)
   - **Image/Logo** – button dabao, phir image/bg-image wale element par tap, gallery se nayi image chuno
   - **Colors** – top 14 colors dikhega, color picker se poori page change (!important)
   - **Link** – link/button par tap karke URL + text badlo
   - **Add** – element ke baad text/heading/button/image add
   - **Delete** – element delete (Undo se wapas)
   - **Undo** – last change undo
   - **Naam badlo** – find/replace (links bhi optional)
   - **Title** – page title badlo
   - **Keep** – is URL (origin+pathname) ke liye edits save (dobara open par auto lag jayenge, original page flash nahi hoga)
   - **Reset** – saved edits hatao + reload
   - **Save** – complete single HTML file (CSS + images inlined as data URI) Downloads mein save
   - **✖** – edit band (confirm se poochhega keep karna hai ya nahi)

5. Desktop site toggle toolbar mein eye/view icon se (Chrome desktop UA + reload).
6. Back button se history, phir app close.
7. http/https links "Open with" se bhi open ho sakte hain (intent-filter + onNewIntent).
8. tel:, mailto:, intent: links external apps mein khulte hain.

**Note**: Edit mode ka koi button/icon/menu nahi dikhta. Sirf 3-tap se khulta hai. Taps site tak bhi pahunchte hain (preventDefault nahi).

## Project structure
```
PSEBrowser/
├── settings.gradle
├── build.gradle
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── .gitignore
├── .github/workflows/build.yml
├── README.md
└── app/
    ├── build.gradle
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/editor.js
        ├── java/com/pse/browser/MainActivity.java
        └── res/
            ├── values/styles.xml
            └── drawable/ic_launcher.xml
```
